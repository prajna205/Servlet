//WishMessageGenerator.java
package com.nt.el;

public class WishMessageGenerator {
	
	public  static String generate(String user) {
		return  "Good Morning::"+user;
	}

}
